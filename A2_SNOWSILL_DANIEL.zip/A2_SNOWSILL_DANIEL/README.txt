Controls:

k: Show Debug
l: launch ball