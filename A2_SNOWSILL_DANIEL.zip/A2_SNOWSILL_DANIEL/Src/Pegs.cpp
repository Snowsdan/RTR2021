#include "Pegs.h"

RTRPegs::RTRPegs() {
	leftPeg = new RTRCube();
	leftPeg->Init("Src/Textures/PurpleBrick.png");
}

void RTRPegs::MovePegs() {

}